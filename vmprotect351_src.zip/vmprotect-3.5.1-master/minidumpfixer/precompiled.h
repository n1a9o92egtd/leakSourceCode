#pragma once
#ifndef MDF_PCH
#define MDF_PCH

#include <stdio.h>
#include <tchar.h>
#include <Windows.h>
#pragma warning( disable : 4091 )
#include <DbgHelp.h>
#include <Shlwapi.h>
#pragma warning( default: 4091 )

#endif //MDF_PCH