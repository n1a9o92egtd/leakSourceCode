#pragma once
#ifndef VMPC_PCH
#define VMPC_PCH

#include "../core/precompiled.h"

#endif //VMPC_PCH